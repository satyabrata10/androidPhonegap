CameraTest-Cordova
==================

This is a project using the camera API on Cordova-CLI.
